import './lesson_8'

console.log('Lesson 8');


// just a plug
export default () => {
};