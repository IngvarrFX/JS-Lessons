import {IGlobalState} from "../state";


export const  selectAllState = (state: IGlobalState) => state.currency